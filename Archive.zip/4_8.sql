SELECT customer_id, customer_name, COUNT(order_id) AS order_count
FROM customer
JOIN ordert USING(customer_id)
GROUP BY customer_id, customer_name
ORDER BY order_count DESC
LIMIT 3;